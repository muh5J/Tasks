# Javascript task

A Pen created on CodePen.io. Original URL: [https://codepen.io/Attia-Ahmed/pen/xxezodO](https://codepen.io/Attia-Ahmed/pen/xxezodO).

